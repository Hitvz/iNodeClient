#!/bin/sh

cd /usr/iNodeClient/
sudo sh uninstall.sh
echo "卸载完毕"
echo "按任意键退出"
read key

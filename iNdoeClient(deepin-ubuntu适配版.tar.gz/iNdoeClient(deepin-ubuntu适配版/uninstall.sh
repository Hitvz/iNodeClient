#!/bin/sh

cd /usr/iNodeClient/
sudo sh uninstall.sh
echo "卸载完毕"

read key
